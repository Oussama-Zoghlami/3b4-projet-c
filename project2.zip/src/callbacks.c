#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_ZOGbuttonajout_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonmodifier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonsuprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonretour_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonreponse_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonretour1_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonterminer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonterminer1_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonchercher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonretour2_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonsuprimer1_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonokay_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ZOGbuttonretour3_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}

